<template>

</template>

<script>
    export default {
        name: "Single"
    }
</script>

<style scoped>

</style>
