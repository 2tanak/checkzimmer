export default {
    name: {
        label: 'Name',
        placeholder: 'Please enter type name',
        type: 'text',
    },
    picture: {
        label: 'Picture',
        placeholder: 'Please enter room type picture',
        type: 'file',
    },
    feature_category: {
        label: 'Категория',
        placeholder: 'Please enter room type category',
        type: 'text',
    }
}
