@extends('layouts.dashboard')

@section('content')
    <div id="application">
        <App></App>
    </div>
@endsection
